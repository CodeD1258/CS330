///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ================
// This file contains the implementation of the `SceneManager` class, which is 
// responsible for managing the preparation and rendering of 3D scenes. It 
// handles textures, materials, lighting configurations, and object rendering.
//
// AUTHOR: Brian Battersby
// INSTITUTION: Southern New Hampshire University (SNHU)
// COURSE: CS-330 Computational Graphics and Visualization
//
// INITIAL VERSION: November 1, 2023
// LAST REVISED: December 1, 2024
//
// RESPONSIBILITIES:
// - Load, bind, and manage textures in OpenGL.
// - Define materials and lighting properties for 3D objects.
// - Manage transformations and shader configurations.
// - Render complex 3D scenes using basic meshes.
//
// NOTE: This implementation leverages external libraries like `stb_image` for 
// texture loading and GLM for matrix and vector operations.
///////////////////////////////////////////////////////////////////////////////
#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
	m_loadedTextures = 0;

	// Add the table material for lighting reflections
	OBJECT_MATERIAL tableMaterial;
	tableMaterial.tag = "tableMaterial";
	tableMaterial.diffuseColor = glm::vec3(0.8f, 0.7f, 0.6f);  // earthy wood diffuse
	tableMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f); // moderate specular
	tableMaterial.shininess = 32.0f;                           // sharp specular highlight
	m_objectMaterials.push_back(tableMaterial);
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			stbi_image_free(image);
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

void SceneManager::LoadSceneTextures()
{
	// Load textures and assign tags
	CreateGLTexture("textures/metal_texture.jpg", "metal");   // For arms
	CreateGLTexture("textures/marble_texture.jpg", "white");  // For lamp head and lamp base
	CreateGLTexture("textures/wood_texture.jpg", "table");    // For table
	CreateGLTexture("textures/leather_texture.jpg", "book");  // For book
	CreateGLTexture("textures/blinds.png", "blinds"); // For background blinds

	// Bind textures after loading them
	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();
	m_basicMeshes->LoadPlaneMesh();      // Tabletop
	m_basicMeshes->LoadCylinderMesh();   // Lamp neck and cup
	m_basicMeshes->LoadConeMesh();       // Lamp head and plant leaves
	m_basicMeshes->LoadSphereMesh();     // Joints
	m_basicMeshes->LoadBoxMesh();        // Books
	m_basicMeshes->LoadTorusMesh();      // Cup handle
}


/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes.
 ***********************************************************/
void SceneManager::RenderScene()
{
	// ==============================
	// COMMON VARIABLES
	// ==============================
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;
	float Xrotation = 0.0f, Yrotation = 0.0f, Zrotation = 0.0f;
	float tableHeight = 1.0f; // base height of table surface

	// ==============================
	// LIGHTING SETUP
	// ==============================
	if (m_pShaderManager != nullptr)
	{
		m_pShaderManager->setBoolValue("bUseLighting", true);

		// Camera position
		glm::vec3 cameraPos(-50.0f, 75.0f, 20.0f);
		m_pShaderManager->setVec3Value("viewPosition", cameraPos);

		// Default material properties
		m_pShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f));
		m_pShaderManager->setVec3Value("material.specularColor", glm::vec3(0.5f));
		m_pShaderManager->setFloatValue("material.shininess", 32.0f);

		// Lamp head point light
		glm::vec3 lampHeadPos = glm::vec3(6.5f, tableHeight + 6.0f, 0.0f);
		m_pShaderManager->setVec3Value("pointLights[0].position", lampHeadPos);
		m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.2f, 0.2f, 0.15f));
		m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(1.0f, 0.95f, 0.7f));
		m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(1.0f, 1.0f, 0.8f));
		m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

		// Deactivate other lights
		for (int i = 1; i < 5; i++)
		{
			std::string activeName = "pointLights[" + std::to_string(i) + "].bActive";
			m_pShaderManager->setBoolValue(activeName, false);
		}
	}

// ==============================
// WALL BEHIND TABLE
// ==============================
	glm::vec3 wallScale(30.0f, 15.0f, 1.0f);
	glm::vec3 wallPos(2.0f, wallScale.y / 2.0f, 15.0f);
	SetTransformations(wallScale, 0.0f, 0.0f, 0.0f, wallPos);
	SetShaderTexture("blinds");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

	// ===== Window light from blinds =====
	glm::vec3 windowLightPos = wallPos + glm::vec3(0.0f, 5.0f, -0.5f); // slightly inside room

	// Point light setup
	m_pShaderManager->setVec3Value("pointLights[1].position", windowLightPos);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", glm::vec3(0.4f, 0.4f, 0.45f));  // soft cool
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", glm::vec3(0.8f, 0.85f, 0.9f)); // bright cool
	m_pShaderManager->setVec3Value("pointLights[1].specular", glm::vec3(0.9f, 0.95f, 1.0f)); // bluish
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// Keep this light active � only deactivate starting at index 2
	for (int i = 2; i < 5; i++)
	{
		m_pShaderManager->setBoolValue("pointLights[" + std::to_string(i) + "].bActive", false);
	}

	// ===== Fake volumetric beam =====
	glm::vec3 beamScale(10.0f, 10.0f, 0.1f); // width & height of light spread
	glm::vec3 beamPos = windowLightPos + glm::vec3(0.0f, -1.0f, -5.0f); // move into room

	// Slight bluish transparent color
	SetTransformations(beamScale, 90.0f, 0.0f, 0.0f, beamPos);
	SetShaderColor(0.8f, 0.85f, 0.95f, 0.3f);
	m_basicMeshes->DrawPlaneMesh();

// ==============================
// TABLE
// ==============================
	glm::vec3 tableScale(20.0f, 1.0f, 10.0f);
	glm::vec3 tablePos(0.0f, tableHeight / 2, 0.0f);
	SetTransformations(tableScale, 0, 0, 0, tablePos);
	SetShaderTexture("table");
	SetTextureUVScale(5.0f, 5.0f);
	m_basicMeshes->DrawPlaneMesh();

// ==============================
// MAT
// ==============================
	glm::vec3 matScale(20.0f, 0.5f, 10.0f);   // Length, thin height, width
	glm::vec3 matPos(-6.0f, 1.0f, -5.0f);    // Adjust Y to sit right on top of table

	SetTransformations(matScale, 0.0f, 0.0f, 0.0f, matPos);
	SetShaderTexture("book");
	SetTextureUVScale(1.0f, 1.0f);
	m_basicMeshes->DrawBoxMesh();

// ==============================
// BOOKS
// ==============================
	float tableHeight1 = 0.5f; // base height of table surface

	// Book 1
	glm::vec3 bookScale1(0.5f, 4.0f, 2.0f);
	glm::vec3 bookPos1(10.0f, tableHeight1 + bookScale1.y / 2.0f, -9.0f); // bottom touches table
	SetTransformations(bookScale1, -180.0f, 0.0f, 0.0f, bookPos1);
	SetShaderTexture("book");
	SetTextureUVScale(1.0f, bookScale1.y);
	m_basicMeshes->DrawBoxMesh();

	// Book 2
	glm::vec3 bookScale2(0.5f, 3.0f, 2.0f);
	glm::vec3 bookPos2 = bookPos1 + glm::vec3(0.5f, 0.0f, 0.0f); 
	bookPos2.y = tableHeight1 + bookScale2.y / 2.0f;             
	SetTransformations(bookScale2, -180.0f, 0.0f, 0.0f, bookPos2);
	SetShaderTexture("book");
	SetTextureUVScale(1.0f, bookScale2.y);
	m_basicMeshes->DrawBoxMesh();

	// Book 3
	glm::vec3 bookScale3(0.5f, 4.0f, 2.0f);
	glm::vec3 bookPos3 = bookPos2 + glm::vec3(0.5f, 0.0f, 0.0f);
	bookPos3.y = tableHeight1 + bookScale3.y / 2.0f;
	SetTransformations(bookScale3, -180.0f, 0.0f, 0.0f, bookPos3);
	SetShaderTexture("book");
	SetTextureUVScale(1.0f, bookScale3.y);
	m_basicMeshes->DrawBoxMesh();

	// Book 4
	glm::vec3 bookScale4(0.5f, 4.5f, 2.0f);
	glm::vec3 bookPos4 = bookPos3 + glm::vec3(0.5f, 0.0f, 0.0f);
	bookPos4.y = tableHeight1 + bookScale4.y / 2.0f;
	SetTransformations(bookScale4, -180.0f, 0.0f, 0.0f, bookPos4);
	SetShaderTexture("book");
	SetTextureUVScale(1.0f, bookScale4.y);
	m_basicMeshes->DrawBoxMesh();


	// ==============================
	// CUP
	// ==============================
	glm::vec3 cupScale(1.0f, 1.5f, 1.0f);
	glm::vec3 cupPos(3.0f, 2.6f, -4.0f);

	// Cup cone
	SetTransformations(cupScale, 180.0f, 0, 0, cupPos);
	SetShaderTexture("white");
	SetTextureUVScale(5.0f, 5.0f);
	m_basicMeshes->DrawConeMesh();

	// Cup Base
	glm::vec3 cupBaseScale(1.0f, 0.1f, 1.2f); // X, Y (height), Z
	glm::vec3 cupBasePos = cupPos - glm::vec3(0.0f, tableHeight1+ cupScale.y / 2 + cupBaseScale.y / 2, 0.0f); // position under cup
	SetTransformations(cupBaseScale, 0.0f, 0.0f, 0.0f, cupBasePos);
	SetShaderTexture("white");
	SetTextureUVScale(5.0f, 5.0f);
	m_basicMeshes->DrawCylinderMesh();

	// Cup handle (torus)
	glm::vec3 handleScale(0.4f); 
	glm::vec3 handlePos = cupPos + glm::vec3(-1.0f, -0.3f, 0.0f); 
	SetTransformations(handleScale, 180.0f, 0.0f, 0.0f, handlePos);
	SetShaderTexture("white");
	SetTextureUVScale(5.0f, 5.0f);
	m_basicMeshes->DrawTorusMesh();


	// ==============================
	// PLANT
	// ==============================
	glm::vec3 potScale(1.0f, 2.0f, 1.0f);  // thinner (x/z) and taller (y)
	glm::vec3 potPos(-15.0f, 1.3f, -4.0f);

	SetTransformations(potScale, 0, 0, 0, potPos);
	SetShaderTexture("white");
	m_basicMeshes->DrawCylinderMesh();

	// Leaves
	glm::vec3 leafScale(0.5f, 2.0f, 0.5f);  // visible leaf size
	SetShaderColor(0.0f, 0.6f, 0.0f, 1.0f);
	float leafRadius = 1.2f;              // distance from pot center
	float leafHeightOffset = potScale.y + 0.1f;  // leaves start above pot

	for (int i = 0; i < 8; i++)
	{
		float angle = i * 45.0f;
		glm::vec3 leafPos = potPos + glm::vec3(
			sin(glm::radians(angle)) * leafRadius,
			leafHeightOffset,
			cos(glm::radians(angle)) * leafRadius
		);
		SetTransformations(leafScale, -60.0f, angle, 0.0f, leafPos); // -30 degrees X rotation tilts leaves up
		m_basicMeshes->DrawConeMesh();
	}


	// ==============================
	// LAMP
	// ==============================
	// Lamp base
	glm::vec3 baseScale(2.0f, 0.2f, 1.5f);
	glm::vec3 basePos(6.5f, tableHeight + baseScale.y / 2, 0.0f);
	SetTransformations(baseScale, 0, 0, 0, basePos);
	SetShaderTexture("white");
	m_basicMeshes->DrawCylinderMesh();

	// Lower arm
	float lowerLen = 5.5f;
	float lowerAngle = -10.0f;
	glm::vec3 lowerArmPos = basePos + glm::vec3(0.0f, baseScale.y / 2, 0.0f);
	SetTransformations(glm::vec3(0.3f, lowerLen, 0.3f), 0, 0, lowerAngle, lowerArmPos);
	SetShaderTexture("metal");
	m_basicMeshes->DrawCylinderMesh();

	// Joint 1
	glm::vec3 joint1Scale(0.4f);
	glm::vec3 joint1Pos = lowerArmPos + glm::vec3(lowerLen * sin(glm::radians(-lowerAngle)), lowerLen * cos(glm::radians(-lowerAngle)), 0.0f);
	SetTransformations(joint1Scale, 0, 0, 0, joint1Pos);
	SetShaderTexture("metal");
	m_basicMeshes->DrawSphereMesh();

	// Upper arm
	float upperLen = 4.5f;
	float upperAngle = 55.0f;
	glm::vec3 upperArmPos = joint1Pos;
	SetTransformations(glm::vec3(0.3f, upperLen, 0.3f), 0, 0, upperAngle, upperArmPos);
	SetShaderTexture("metal");
	m_basicMeshes->DrawCylinderMesh();

	// Joint 2
	glm::vec3 joint2Scale(0.4f);
	glm::vec3 joint2Pos = upperArmPos + glm::vec3(upperLen * sin(glm::radians(upperAngle)),upperLen * cos(glm::radians(upperAngle)), 0.0f);
	SetTransformations(joint2Scale, 0, 0, 0, joint2Pos);
	SetShaderTexture("metal");
	
	
	// Lamp head (fixed placement)
	glm::vec3 headScale(1.2f, 2.0f, 1.2f);
	glm::vec3 headPos = joint2Pos + glm::vec3(-9.0f, -1.0f, 0.0f); 
	SetTransformations(headScale, 180.0f, 0.0f, 120.0f, headPos);
	SetShaderTexture("white");
	m_basicMeshes->DrawConeMesh();
}
